# version.py
__version__ = '2.5.3'
# __version__ = '2.5dev2'

