# version.py
__version__ = '2.5.5'
# __version__ = '2.5dev2'

